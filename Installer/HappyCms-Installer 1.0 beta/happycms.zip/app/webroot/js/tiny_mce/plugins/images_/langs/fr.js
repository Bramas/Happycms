tinyMCE.addI18n('fr.images',{
	desc : "Upload d'une image et l'ins&eacute;rer"
});