tinyMCE.addI18n('en.images_dlg',{
title:"Pictures",
del_sel_folder:"Remove selected folder?",
sel_files_for_del:"Select files for removal.\n\nYou can remove several files simultaneously by selecting it with Ctrl.",
files_to_del:"Files for removal",
delete_str:"Remove",
create_new_fld:"Create new folder",
create_fld:"Create folder",
upload_files:"Upload files",
delete_file:"Delete file",

fancy_title:"Image uploading",
fancy_back_alt:"Back to files list",
fancy_back:"Back to files",
fancy_browse:"Browse",
fancy_begin_upload:"Start upload",
fancy_upload_files:"Upload files",
fancy_clear:"Clear list",
fancy_begin_upload_files:"Start files upload",
fancy_general_status:"General status",
fancy_file_status:"File status"
});