<?php
//session_start();

include 'tinyimages.php';

$images = new tinyimages();
$images->UploadFiles();
?>