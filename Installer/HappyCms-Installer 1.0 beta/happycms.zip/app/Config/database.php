<?php

class DATABASE_CONFIG {

	var $default = array(
		'datasource' => 'Database/Mysql',
		'driver' => 'mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'root',
		'password' => '',
		'database' => 'happycms',
		'prefix' => '',
		'encoding' => 'utf8'
	);

}
