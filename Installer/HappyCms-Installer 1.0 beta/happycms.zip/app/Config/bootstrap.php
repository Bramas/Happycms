<?php

CakePlugin::loadAll();
require_once '../Plugin/HappyCms/Config/bootstrap.php';
require_once '../Plugin/Media/Config/bootstrap.php';

?>