<?php

class LinksController extends AppController
{
    
   var $uses =  array();
    var $helpers = array('Html');
    function admin_index_edit()
    {
        
    }
    
    function index()
    {
        
    }
    
}
    
    