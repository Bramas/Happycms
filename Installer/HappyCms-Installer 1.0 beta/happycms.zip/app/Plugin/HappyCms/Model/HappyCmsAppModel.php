<?php
App::uses('AppModel','Model');
class HappyCmsAppModel extends AppModel
{
	
}