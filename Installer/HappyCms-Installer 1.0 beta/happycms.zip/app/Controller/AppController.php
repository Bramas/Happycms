<?php

App::uses('HappyCmsController','HappyCms.Controller');

class AppController extends HappyCmsController {



}
?>