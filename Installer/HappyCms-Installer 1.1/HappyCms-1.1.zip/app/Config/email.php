<?php
class EmailConfig {
    public $and1 = array(
        'host' => 'ssl://auth.smtp.1and1.fr',
        'port' => 465,
        'username' => 'contact@ocal-billom.fr',
        'password' => 'MAIL@ocal123',
        'transport' => 'Smtp',
        'emailFormat'=>'html'
    );
}