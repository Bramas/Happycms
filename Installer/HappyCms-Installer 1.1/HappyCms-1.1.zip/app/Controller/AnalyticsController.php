<?php

class CategoriesController extends AppController
{
    var $uses =  array();
    
    function admin_test()
    {
    	
    }
}