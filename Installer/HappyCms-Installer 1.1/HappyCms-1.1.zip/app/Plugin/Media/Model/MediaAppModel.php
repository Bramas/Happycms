<?php
class MediaAppModel extends AppModel {
       
}
?>