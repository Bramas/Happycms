<?php
class HappyCmsAppController extends AppController
{

}
