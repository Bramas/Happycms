/*
 *	Bulgarian translation
 *	Author:		Valentin Hristov
 *	Company:	SOFTKIT Bulgarian
 *	Site:		http://www.softkit-bg.com
 */
editArea.add_lang("bg",{
charmap_but: "Виртуална клавиатура",
charmap_title: "Виртуална клавиатура",
charmap_choose_block: "избери езиков блок",
charmap_insert:"постави този символ"
});
