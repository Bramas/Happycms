<?php
class MiniSqlController extends AppController
{
  
  function admin_index()
  {




    exit();
  }
}
?>