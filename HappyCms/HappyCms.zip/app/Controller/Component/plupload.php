<?php
class PluploadComponent extends Object{



/**
 * Startup component
 *
 * @param object $controller Instantiating controller
 * @access public
 */
	function startup(&$controller) {}
        
        
}

?>