tinyMCE.addI18n('fr.images_dlg',{
title:"Images",
del_sel_folder:"Supprimer ce dossier ?",
sel_files_for_del:"S&eacute;lectionnez les fichiers &agrave; supprimer.\n\nVous pouvez supprimer plusieurs fichiers en m�me temps en le s&eacute;lectionnant avec la touche Ctrl.",
files_to_del:"Fichiers &agrave; supprimer",
delete_str:"	Supprimer",
create_new_fld:"Cr&eacute;er un nouveau dossier",
create_fld:"Cr&eacute;er un dossier",
upload_files:"Upload des fichiers",
delete_file:"Supprimer le fichier",

fancy_title:"Image uploading",
fancy_back_alt:"	Retour &agrave; la liste des fichiers",
fancy_back:"Retour aux dossiers",
fancy_browse:"Parcourir",
fancy_begin_upload:"D&eacute;marrer upload",
fancy_upload_files:"Upload des fichiers",
fancy_clear:"Effacer la liste",
fancy_begin_upload_files:"D&eacute;but upload de fichiers",
fancy_general_status:"Etat",
fancy_file_status:"Etat du fichier"
});